//
//  ViewController.swift
//  0321
//
//  Created by Macbook on 2022/3/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var result: UILabel!
    
    @IBOutlet weak var Cleaner: UIButton!
    @IBOutlet weak var process: UILabel!
    @IBOutlet var CalButton: [UIButton]!
    var Number:Int = 0
    var FowardNum:Float = 0.0
    var MathCal:Bool = false
    var First:Bool = true
    var ACC:Bool = false
    var point:Bool = false
    var EqualFlag:Bool = false
    var Symbols = ["x","/","-","+"]
    var Operator:Array<String> = []
    var Operand:Array<Float> = []
    var BeforeOp:Int = 0
    @IBAction func Operation(_ sender: UIButton) {
        
        if result.text != ""{
            let Symbol = sender.titleLabel?.text
            FowardNum = Float(result.text!)!
            
            /*if First{
                if Operand[0].truncatingRemainder(dividingBy: 1) == 0.0{
                    process.text = String(format:"%.0f", FowardNum)
                }
                else{
                    process.text = String(FowardNum)
                }
                First = false
            }*/
            if Symbol != "="{
                if Symbol == "%"{
                    FowardNum = FowardNum/100
                    
                    result.text = String(FowardNum)
                    process.text = getProcess() + TransString(x:FowardNum)
                }else{
    
                sender.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                sender.setTitleColor(.blue, for: .normal)
                
                result.text = "0"
                Operator.append(Symbol!)
                Operand.append(FowardNum)
                process.text = getProcess()
                MathCal = true
                point = false
                }
                
            }else{
                Operand.append(FowardNum)
                process.text = getProcess()
                point = false
                ACC = true
                Cleaner.setTitle("AC", for: .normal)
                process.text! += Symbol!
                for y in 0...3{
                    var x = 0
                    while(Operand.count > 1 && x < Operator.count){
                        if  Operator[x] == Symbols[y]{
                            switch y{
                            case 0:
                                Operand[x] = Operand[x]*Operand[x+1]
                                break
                            case 1:
                                Operand[x] = Operand[x]/Operand[x+1]
                                break
                            case 2:
                                Operand[x] = Operand[x]-Operand[x+1]
                                break
                            case 3:
                                Operand[x] = Operand[x]+Operand[x+1]
                                break
                            default:
                                break
                            }
                            Operand.remove(at: x+1)
                            Operator.remove(at: x)
                            print(Operand)
                            print(Operator)
                        }else{
                            x += 1
                        }
                    }
                }
                
                result.text = TransString(x:Operand[0])
                
                EqualFlag = true
            }
            
           
            
        }
        
        
    }
    func getProcess() -> String{
        var Temp:String = ""
        var x = 0
        while x < Operand.count{
            Temp += TransString(x: Operand[x])
            if x < Operator.count{
                Temp += String(Operator[x])
            }
            x += 1
            }
        
        return Temp
    }
    func TransString(x: Float) -> String{
        if x.truncatingRemainder(dividingBy: 1) == 0.0{
            return String(format:"%.0f", Operand[0])
        }
        else{
            var len = 0
            let Temp = String(x).split(separator: ".")
            print(Temp)
            Temp[1].forEach{f in
                if f == "0"{
                    len += 1
                }else{
                    len = 0
                }
            }
            return String(Temp[0] + "." + Temp[1].prefix(Temp[1].count - len))
                
            
        }
    }
    @IBOutlet var operation: [UIButton]!
    @IBAction func Cal(_ sender: UIButton){
        let inputNum = sender.titleLabel?.text
        if inputNum == "." && point == true{
            
        }else{
        if inputNum == "."{
             point = true
        }
        if EqualFlag == true{
            Clean(Cleaner)
            EqualFlag = false
        }
        if MathCal == false{
            process.text! += inputNum!
            result.text! += inputNum!
        }
        else{
        for y in operation{
            y.setTitleColor(.white, for: .normal)
            y.backgroundColor = #colorLiteral(red: 0, green: 0.4773510695, blue: 0.8913187981, alpha: 1)
        }
            
            process.text! += inputNum!
            result.text = inputNum!
            First = false
            MathCal = false
        }
            ACC = false
        Cleaner.setTitle("C", for: .normal)
    
        }
    }
    @IBAction func Clean(_ sender: UIButton) {

        if ACC == true{
            FowardNum = 0
            MathCal = false
            First = true
            Operand.removeAll()
            Operator.removeAll()
            process.text = ""
            result.text = "0"
        }else if result.text != "0"{
            process.text = getProcess()
            result.text = "0"
            Cleaner.setTitle("AC", for: .normal)
            ACC = true
        }
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

